# CR Drive server

The production server is not configured yet. `supabase/schema.sql` defines the minimum data model for organizations, consented monitoring sessions and timestamped telemetry.

Before deployment configure Supabase authentication, organization membership policies, Row Level Security and a protected `/v1/telemetry` ingestion endpoint. The mobile app reads its base URL from `EXPO_PUBLIC_TELEMETRY_API_URL` and refuses to upload when it is missing.

No generated telemetry is accepted as live server data. Dispatcher views must distinguish current, stale and offline records using `captured_at` and `received_at`.
