create table organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table organization_members (
  organization_id uuid not null references organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('dispatcher','driver','admin')),
  primary key (organization_id,user_id)
);

create table monitoring_sessions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id),
  driver_id uuid not null references auth.users(id),
  consented_at timestamptz not null,
  started_at timestamptz not null default now(),
  ended_at timestamptz
);

create table telemetry (
  id bigint generated always as identity primary key,
  session_id uuid not null references monitoring_sessions(id) on delete cascade,
  driver_id uuid not null references auth.users(id),
  bpm smallint check (bpm between 1 and 255),
  latitude double precision,
  longitude double precision,
  accuracy real,
  bracelet_connected boolean not null,
  captured_at timestamptz not null,
  received_at timestamptz not null default now()
);

create index telemetry_session_time_idx on telemetry(session_id,captured_at desc);
create index telemetry_driver_time_idx on telemetry(driver_id,captured_at desc);

alter table organizations enable row level security;
alter table organization_members enable row level security;
alter table monitoring_sessions enable row level security;
alter table telemetry enable row level security;

-- Policies must be completed after the production authentication and role model are configured.
