import test from 'node:test';import assert from 'node:assert/strict';
class TelemetryBuffer{constructor(flush){this.queue=[];this.flush=flush}push(packet){this.queue.push(packet)}drain(){const latest=Object.assign({},...this.queue.splice(0));if(Object.keys(latest).length)this.flush(latest)}}
test('telemetry batches packets and keeps latest fields',()=>{let result;const b=new TelemetryBuffer(v=>result=v);b.push({heart:70,gps:[1,2]});b.push({heart:72});b.drain();assert.deepEqual(result,{heart:72,gps:[1,2]})});
test('empty telemetry drain does not rerender',()=>{let calls=0;const b=new TelemetryBuffer(()=>calls++);b.drain();assert.equal(calls,0)});
