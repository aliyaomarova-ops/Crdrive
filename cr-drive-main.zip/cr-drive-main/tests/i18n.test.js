import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  applyLanguage,
  bindings,
  defaultLanguage,
  dictionaries,
  getLanguage,
  getNextLanguage,
  supportedLanguages,
  t
} from '../dist/i18n.js';

test('all supported languages provide every UI translation', () => {
  const keys = Object.keys(dictionaries.en).sort();

  for (const language of supportedLanguages) {
    assert.deepEqual(Object.keys(dictionaries[language]).sort(), keys, `${language} dictionary keys`);
    for (const [key, value] of Object.entries(dictionaries[language])) {
      assert.equal(typeof value, 'string', `${language}.${key} must be text`);
      assert.notEqual(value.trim(), '', `${language}.${key} must not be empty`);
    }
  }
});

test('every rendered UI binding has a translation in every supported language', () => {
  const boundKeys = [...new Set(bindings.map(([key]) => key))];

  for (const language of supportedLanguages) {
    for (const key of boundKeys) {
      assert.notEqual(dictionaries[language][key], undefined, `${language}.${key} is bound to the interface`);
    }
  }
});

test('homepage hero title stays static English in every language', () => {
  const html = readFileSync(new URL('../dist/index.html', import.meta.url), 'utf8');
  const titleMarkup = 'EVERY<br><span>HEARTBEAT</span><br>MATTERS.';

  assert.ok(html.includes(`<h1 class="reveal">${titleMarkup}</h1>`));
  assert.equal(bindings.some(([key]) => key === 'hero.title'), false);
  for (const language of supportedLanguages) {
    assert.equal(Object.hasOwn(dictionaries[language], 'hero.title'), false);
    applyLanguage(language);
    assert.equal(getLanguage(), language);
  }
});

test('language selection cycles through Russian, English, and Kazakh', () => {
  assert.equal(defaultLanguage, 'ru');
  assert.equal(getNextLanguage('ru'), 'en');
  assert.equal(getNextLanguage('en'), 'kk');
  assert.equal(getNextLanguage('kk'), 'ru');
});

test('language changes share one translation state and unknown keys stay hidden', () => {
  for (const language of supportedLanguages) {
    applyLanguage(language);
    assert.equal(getLanguage(), language);
    assert.equal(t('nav.platform'), dictionaries[language]['nav.platform']);
  }

  assert.equal(t('missing.translation'), '');
  applyLanguage('invalid');
  assert.equal(getLanguage(), defaultLanguage);
});
