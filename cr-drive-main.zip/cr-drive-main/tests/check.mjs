import fs from 'node:fs';
const html=fs.readFileSync(new URL('../dist/index.html',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../dist/styles.css',import.meta.url),'utf8');
const typography=fs.readFileSync(new URL('../dist/typography.css',import.meta.url),'utf8');
const logo=fs.readFileSync(new URL('../dist/assets/logo.svg',import.meta.url),'utf8');
for(const needle of ['CR Drive','EVERY HEARTBEAT','FLEET CONTROL CENTER','SMART ALERTS','DEVICE HEALTH','CONNECT YOUR BRACELET','data-dashboard','data-mode="demo"','data-mode="live"','prefers-reduced-motion','Instagram · CR Drive','Official URL not provided']){if(!html.includes(needle)&&!css.includes(needle))throw new Error(`Missing ${needle}`)}
for(const file of ['../dist/app.js','../dist/styles.css','../dist/typography.css','../dist/assets/logo.svg','../dist/assets/favicon.svg','../dist/assets/fonts/manrope-variable.ttf','../dist/assets/fonts/OFL.txt']){if(!fs.existsSync(new URL(file,import.meta.url)))throw new Error(`Missing ${file}`)}
if(!html.includes('href="typography.css"'))throw new Error('Typography stylesheet must be linked from the website');
if((html.match(/<img src="assets\/logo\.svg"/g)||[]).length!==2)throw new Error('Navbar and footer must reuse the shared logo asset');
if(!logo.includes('CR DRIVE')||!logo.includes('viewBox="0 0 260 56"'))throw new Error('Shared logo must preserve its wordmark and aspect ratio');
if(!typography.includes('.brand img')||!typography.includes('object-fit:'))throw new Error('Shared logo sizing rules are missing');
if(!typography.includes('font-family: Manrope;')||!typography.includes('html[lang="kk"]'))throw new Error('Kazakh Manrope font configuration is missing');
if(!typography.includes('max-width: 42%')||!typography.includes('.feature-wide .mini-map'))throw new Error('Fleet headline must stay clear of the desktop map');
for(const security of ["Content-Security-Policy","Permissions-Policy","object-src 'none'"]){if(!html.includes(security))throw new Error(`Missing security control: ${security}`)}
if(/instagram\.com/i.test(html))throw new Error('Instagram URL must not be invented before the official account is provided');
console.log('CR drive static checks passed');
