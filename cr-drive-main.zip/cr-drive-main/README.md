# CR Drive

CR Drive is a driver-wellbeing product prototype. The repository contains a static product website and dashboard demonstration, a separate Android-focused mobile app prototype, an initial Supabase data-model draft, and a small Node.js test/check suite. These pieces are not yet connected into a production telemetry system.

The website and mobile app must be treated as separate applications:

- The website is served from [`dist/`](dist/) and displays a clearly labeled simulated fleet dashboard. Its Live mode is an empty connection state, not a live service.
- The mobile app is in [`mobile/`](mobile/). It has local demo monitoring, BLE and telemetry service scaffolding, and SQLite trip history. It does not currently authenticate users or upload telemetry through the app flow.
- [`server/supabase/schema.sql`](server/supabase/schema.sql) is a schema draft, not a deployed or complete backend.
- Bracelet firmware is not present. [`hardware/README.md`](hardware/README.md) records the missing hardware/protocol decisions.

## Project overview and status

The intended product helps drivers and fleet operators monitor heart-rate and trip signals. The public-facing content describes bracelet-to-phone-to-control-center data flow, driver permission, device health, and fleet alerts. In the current repository, most of that end-to-end functionality is represented by UI, simulated data, or an unconnected interface rather than a deployed service.

| Area | Implemented in this repository | Not implemented or not connected |
|---|---|---|
| Website | Static responsive marketing site; demo dashboard with generated fleet metrics and activity; simulated alert and pairing interactions; explicit empty Live state | Real-time server connection, dashboard authentication, fleet data, map/GPS view, real pairing |
| Mobile | Expo/React Native screens; generated heart-rate samples; foreground location permission request; Android BLE scan helper; SQLite trip persistence | Production login/consent, real trip location collection, route storage, actual production bracelet UUID/configuration, live telemetry upload wired into the app, working cloud sync |
| Backend | SQL draft for organizations, memberships, monitoring sessions, and telemetry; RLS enabled on those tables | Deployed Supabase project, completed RLS policies, API/ingestion endpoint, server authorization and validation |
| Hardware | Product direction and integration notes | Selected bracelet/sensor, firmware, packet protocol, and agreed BLE GATT UUIDs |

Health figures and alerts in the demonstrations are not medical readings or advice. The mobile screens explicitly describe this limitation.

## Technology stack

| Technology | Version/configuration | Purpose |
|---|---|---|
| HTML, CSS, browser JavaScript ES modules | No framework or build system declared | Static website structure, styles, responsive navigation, animations, and demo interactions in `dist/` |
| Node.js | Required to run the repository test scripts; a minimum version is not declared for the root package | Built-in test runner and static checks |
| Expo / React Native | Expo `~56.0.0`, React Native `0.85.3`, React `19.2.3` | Independent mobile application and native Android build |
| TypeScript | `~6.0.3`, strict mode enabled | Mobile app and service implementation |
| Expo modules | `expo-location`, `expo-sqlite`, `expo-status-bar`, `expo-linear-gradient` | Foreground location permission, local SQLite, status bar, and gradient capability. The source currently imports location, SQLite, and status bar; `expo-linear-gradient` is declared but not used by the inspected app code. |
| BLE | `react-native-ble-plx` | Android Bluetooth permission, scan, connection, and characteristic-notification helper |
| SVG and icons | `react-native-svg`, `lucide-react-native`, `@expo/vector-icons` | Mobile charts/illustrations and icons; the app imports Lucide and SVG directly |
| Other declared mobile packages | `@expo/config-plugins`, `react-native-safe-area-context` | Present in the dependency manifest; direct use is not visible in the inspected app source. |
| EAS Build | EAS CLI is invoked through `npx`; CLI version is not pinned in the project | Remote Android APK builds using `mobile/eas.json` |
| Supabase SQL conventions | No Supabase client/server dependency is configured | Draft schema references Supabase Auth users and enables PostgreSQL row-level security |

The mobile dependency versions are declared in [`mobile/package.json`](mobile/package.json) and locked in [`mobile/package-lock.json`](mobile/package-lock.json). Some dependencies use `latest`, so the manifest alone does not pin their intended upstream version; the lockfile resolves versions for `npm ci`. The root [`package.json`](package.json) contains no runtime dependencies.

## Project structure

```text
.
├── .gitignore
├── .openai/
│   └── hosting.json                 # Static host configuration: serve dist/
├── package.json                     # Root Node scripts; no dependencies
├── README.md                        # This technical reference
├── dist/                            # Website files served as the static site
│   ├── index.html                   # Website markup and all page sections
│   ├── app.js                       # Browser interactions and demo dashboard state
│   ├── styles.css                   # Stylesheet referenced by index.html
│   ├── i18n.js                      # Language dictionaries; not imported by index.html
│   ├── *-v*.css                     # Additional CSS files not linked by index.html
│   ├── assets/
│   │   ├── favicon.svg
│   │   └── logo.svg
│   └── .openai/hosting.json         # Duplicate static-host directory configuration
├── hardware/
│   └── README.md                    # Hardware choices and firmware status
├── mobile/
│   ├── .env.example                 # Example telemetry API base URL
│   ├── README.md                    # Mobile-specific setup and known limitations
│   ├── app.json                     # Expo identity, Android permissions, native plugins
│   ├── eas.json                     # EAS development/preview/production profiles
│   ├── index.ts                     # Expo root registration
│   ├── package.json                 # Mobile scripts and dependencies
│   ├── package-lock.json            # npm dependency lockfile
│   ├── tsconfig.json                # Expo TypeScript base, strict checks
│   └── src/
│       ├── App.tsx                  # Screens, navigation, app state, trip/demo flow
│       ├── theme.ts                 # Shared colors and radii
│       ├── types.ts                 # Shared app and telemetry domain types
│       └── services/
│           ├── ble.ts               # BLE permissions, scanning, connect/notify, teardown
│           ├── database.ts          # SQLite trip table and persistence functions
│           ├── demoEngine.ts        # Synthetic heart-rate sample generator
│           └── telemetry.ts         # Telemetry packet type and HTTP client helper
├── server/
│   ├── README.md                    # Explicit backend readiness notes
│   └── supabase/
│       └── schema.sql               # Initial relational schema and RLS enablement
└── tests/
    ├── check.mjs                    # Static website content/security assertions
    └── telemetry.test.js            # Tests a local TelemetryBuffer test double
```

`dist/index.html` loads only `dist/styles.css` and `dist/app.js`. The additional versioned CSS files and `i18n.js` are present but are not included by that HTML entry point; do not assume they affect the deployed website. No source-to-dist build command or source directory for these static assets is declared.

Directories such as `mobile/android/`, `mobile/ios/`, `mobile/.expo/`, and dependency directories are ignored by [`.gitignore`](.gitignore) or generated locally. `expo prebuild` creates native project files; do not treat generated native output as the canonical source. The `dist/` tree is the actual static website served by the hosting config, not an expendable generated build directory.

## Architecture and application flow

### Static website

The static hosting configuration in [`.openai/hosting.json`](.openai/hosting.json) points to `dist/`. Browser startup is direct: `index.html` loads its stylesheet and JavaScript module. There is no client-side router; the navigation uses in-page section anchors.

`app.js` wires the responsive navigation menu, scroll state, reduced-motion-aware reveal effects, toast messages, demo pairing, and dashboard mode. Demo mode fills the dashboard with hard-coded/synthetic values and updates a few statistics periodically. Live mode clears the demo view and shows “No live connection”/“NO LIVE DATA”; it makes no network request. The website JavaScript does not import the separate `i18n.js` dictionary file.

```mermaid
flowchart TD
    H["dist/index.html"] --> C["dist/styles.css"]
    H --> J["dist/app.js"]
    J --> NAV["Anchor navigation and UI interactions"]
    J --> DEMO["Generated demo metrics and activity"]
    J --> LIVE["Empty Live state; no server request"]
```

Website sections include the product/platform explanation, control-center concept, alert and bracelet interaction demos, dashboard, security messaging, and footer. The drawn maps, bracelet display, fleet metrics, and events are illustrative, not device or location data.

The HTML declares a meta Content Security Policy that restricts scripts, styles, images, fonts, and connections to the same origin (with data images allowed), disallows objects/frames, and upgrades insecure requests. Its Permissions Policy disables camera, microphone, geolocation, payment, and USB access for the page. These are static-page headers in markup, not a substitute for deployment-level response headers or a backend security design.

### Mobile app

`mobile/index.ts` registers `src/App.tsx` with Expo. `App.tsx` owns the five tabs—Home, Bluetooth, Monitoring/Analytics, Trips/History, and Settings/Profile—and keeps current samples, band status, demo mode, active trip, discovered devices, and trip list in React state. `theme.ts` and `types.ts` provide shared presentation values and model types.

```mermaid
flowchart TD
    I["mobile/index.ts"] --> A["src/App.tsx"]
    A --> UI["Five screen components and tab state"]
    A --> DEMO["DemoHeartEngine"]
    A --> BLE["CRDriveBleClient"]
    A --> LOC["expo-location permission request"]
    A --> DB["SQLite trip service"]
    A -. "not called from App flow" .-> TEL["telemetry.ts HTTP helper"]
    BLE -. "UUID config required" .-> HW["Unspecified bracelet firmware"]
    TEL -. "endpoint not implemented here" .-> API["Planned /v1/telemetry service"]
```

The current demo flow generates heart samples locally. Starting a trip requests foreground location permission, creates an in-memory trip, and starts demo monitoring if the band is not marked connected. It does not read GPS coordinates or calculate a route; trip distance and speed are synthetic values updated by a timer. Stopping a trip writes it to SQLite and prepends it to the in-memory history. On startup, the app initializes the database and reads the latest 100 saved trips.

The BLE service can request Android permissions, scan for named devices, connect to a selected `Device`, discover GATT services, and subscribe to heart-rate characteristic notifications. However, `App.tsx` currently invokes scanning or demo connection, not the service's real-device `connect()` method. No production BLE UUID values are supplied. Treat real-band connection as incomplete.

There is no global state library, navigation package, or shared API layer. Screen selection and application data are held directly in `App.tsx`; local UI-only state (for example the analytics period selector) is held in screen components. Several async errors are either converted to alerts or suppressed by empty catches in the current implementation; do not mistake a suppressed error for a successful save or location read.

### Backend and hardware boundary

`server/supabase/schema.sql` defines a possible PostgreSQL model for Supabase. The repository does not contain a server application, Supabase client, migration runner, auth UI, or API route. Its RLS statements only enable row-level security; the SQL explicitly leaves policies to be completed. No production telemetry ingestion, role authorization, retention policy, or dispatcher dashboard data flow exists yet.

The mobile telemetry helper reads `EXPO_PUBLIC_TELEMETRY_API_URL` and targets `/v1/telemetry`; it accepts an access token argument. The helper is not called from `App.tsx`, no access-token provider is implemented, and the server endpoint is not present. Do not infer a supported production API contract from the client type alone.

The hardware notes say the sensor, Bluetooth module, and protocol are undecided. No firmware exists in this repository, and no GATT UUID should be invented to activate a real-device flow.

## Component and module reference

### Website modules

| File | Responsibility and interface | Dependencies / limitations |
|---|---|---|
| [`dist/index.html`](dist/index.html) | Static document, semantic sections, accessible navigation controls, demo dashboard elements | Loads `styles.css` and `app.js`; all interactions are selected through `data-*` attributes |
| [`dist/app.js`](dist/app.js) | Binds navigation, scroll/reveal effects, toast, simulated alert/pairing, and Demo/Live dashboard state. Exports `TelemetryBuffer`. | DOM APIs and HTML `data-*` selectors; demo-only, no fetch/network integration |
| [`dist/styles.css`](dist/styles.css) | Production page and dashboard stylesheet | Only stylesheet referenced by the HTML |
| [`dist/i18n.js`](dist/i18n.js) | Contains Russian and Kazakh translation dictionaries | Not referenced or imported; no language-switch behavior wired |
| [`dist/*-v*.css`](dist/) | Additional design/patch stylesheet files | Not loaded by current HTML; status as source or historical iterations is undocumented |

`TelemetryBuffer` queues objects, merges queued fields with later values winning, and flushes after a default 900 ms delay. Its tests use a separate local test implementation rather than importing `app.js`.

### Mobile modules

| File / export | Responsibility | Important dependencies and callers |
|---|---|---|
| [`mobile/src/App.tsx`](mobile/src/App.tsx) — default `App` | Owns tab routing, sample/band/trip state, startup initialization, and screen composition. Contains `HomeScreen`, `AnalyticsScreen`, `TripsScreen`, `BandScreen`, and `ProfileScreen`. | Expo/React Native UI, Location, BLE client, demo engine, SQLite functions, shared types/theme |
| [`mobile/src/services/demoEngine.ts`](mobile/src/services/demoEngine.ts) — `DemoHeartEngine` | Starts/stops a 1.5-second synthetic BPM sample stream; samples are marked `demo: true` | Called by the app demo pairing/trip flow |
| [`mobile/src/services/ble.ts`](mobile/src/services/ble.ts) — `CRDriveBleClient` | Requests Android BLE permissions, scans for named devices, connects, discovers GATT, parses heart-rate notifications, and tears down subscriptions | `react-native-ble-plx`, React Native permissions, `BleConfig`/`HeartSample`; real connect requires UUID configuration |
| [`mobile/src/services/database.ts`](mobile/src/services/database.ts) — `initDatabase`, `saveTrip`, `listTrips` | Opens `crdrive.db`, creates the `trips` table, upserts trip rows, reads up to 100 newest trips | Expo SQLite and `Trip`; samples are serialized to JSON in `samples_json` |
| [`mobile/src/services/telemetry.ts`](mobile/src/services/telemetry.ts) — `isTelemetryConfigured`, `sendTelemetry` | Describes a telemetry packet and provides a POST helper gated by configured URL and non-empty access token | Environment URL and `fetch`; currently not wired to app screens or a repository backend |
| [`mobile/src/types.ts`](mobile/src/types.ts) | Shared `Tab`, `SignalQuality`, `HeartSample`, `AlertEvent`, `Trip`, `BandState`, and `BleConfig` types | Used across the app and services |
| [`mobile/src/theme.ts`](mobile/src/theme.ts) | Shared color palette and corner-radius constants | Imported by `App.tsx` |
| [`mobile/index.ts`](mobile/index.ts) | Expo `registerRootComponent` entry point | Imports the default app component |

The app has no separate page directory or service injection layer. Before splitting or adding abstractions, preserve the current distinction between demo data and device-derived data, including the `demo` marker on samples/trips.

## Data model and API reference

### Mobile-local SQLite

The table is created at runtime by `initDatabase()` in `mobile/src/services/database.ts`:

| Column | Type / behavior |
|---|---|
| `id` | Text primary key |
| `started_at`, `ended_at` | Integer epoch timestamps; end may be null |
| `distance_km`, `average_speed` | Real values, default to zero |
| `samples_json` | Required serialized heart-sample array |
| `alerts` | Integer, default zero |
| `demo` | Integer boolean marker, default zero |

`saveTrip()` uses an insert-or-replace operation; `listTrips()` sorts newest first and limits results to 100. There are no separate database tables for users, devices, alerts, or location points.

### Supabase draft schema

The SQL draft defines:

- `organizations`: UUID and name.
- `organization_members`: organization/user membership, referencing `auth.users`, with `dispatcher`, `driver`, or `admin` role values.
- `monitoring_sessions`: organization, driver, consent timestamp, start and optional end timestamps.
- `telemetry`: session/driver references, optional BPM and coordinates/accuracy, required bracelet-connected flag, captured and received timestamps.
- Indexes on telemetry by session/time and driver/time.

Foreign keys express the organization-to-membership/session relationships and the session-to-telemetry relationship. RLS is enabled on all four tables, but no policies are defined. The schema is not accompanied by an applied migration or a configured database. These are proposed structures only; no active server-side CRUD behavior can be verified.

### HTTP

The mobile helper defines a `TelemetryPacket` with `driverId`, `sessionId`, a `HeartSample`, latitude/longitude, optional accuracy, and `capturedAt`. It is written to target `POST {EXPO_PUBLIC_TELEMETRY_API_URL}/v1/telemetry` and requires a non-empty access-token argument. The endpoint, auth issuer, server-side request/response schema, error response contract, and persistence behavior are not implemented in this project. There are no other implemented API endpoints.

## Setup and development

### Static website and root checks

The static site is hosted from `dist/` according to `.openai/hosting.json`. There is no root build, bundler, or dev-server script. Use a static HTTP server that serves this directory for browser testing; hosting/deployment provider details beyond the checked-in directory setting are not documented.

The root package has no dependencies or install step. From the repository root:

```sh
npm test
npm run check
```

`npm test` runs Node's built-in test runner against `tests/*.test.js`. `npm run check` executes `tests/check.mjs`, which asserts expected website content/assets and selected security headers and rejects an unprovided Instagram URL.

### Mobile Android app

The mobile README specifies Node.js `20.19+` and Android Studio or an Android device. Android SDK/JDK version requirements are not declared in the repository. From `mobile/`:

```sh
npm ci
npx expo prebuild
npx expo run:android
```

Or use the package scripts:

```sh
npm run start
npm run android
npm run typecheck
```

`start` uses Expo's dev-client mode; `android` runs the native Android project. Expo Go is not sufficient for `react-native-ble-plx`; use a development build for BLE. `prebuild` regenerates native project files and should be treated as a generated-output operation, especially where a local native project may contain changes.

For an internal preview APK, the configured EAS profile is `preview`:

```sh
npx eas-cli@latest login
npx eas-cli@latest build --platform android --profile preview
```

The `build:apk` script expects an `eas` executable on the path; EAS CLI is not listed as a project dependency. `mobile/eas.json` also declares `development` and `production` profiles. No automated deployment pipeline or backend deployment steps are included.

### Environment variables

| Name | Used by | Required? | Purpose and notes |
|---|---|---|---|
| `EXPO_PUBLIC_TELEMETRY_API_URL` | `mobile/src/services/telemetry.ts` | Optional for the current demo app; required for the telemetry helper to attempt an upload | Base URL; helper appends `/v1/telemetry`. Example name/value placeholder is in `mobile/.env.example`. Expo `EXPO_PUBLIC_` values are bundled into client code; this must not contain a secret. |
| Access token argument (not an environment variable) | `sendTelemetry(packet, accessToken)` | Required if calling the helper | No token acquisition/authentication flow exists in this repository. |

The project has no other environment-variable reads in the inspected code. The root `.gitignore` pattern excludes `.env` files while retaining `.env.example`.

## Development guide for future AI agents

Start with the affected module and its nearest integration point; do not assume the website, mobile app, backend draft, or hardware notes are already connected. Keep simulated and real data visibly distinguished.

| Task | Primary files/directories | Related dependencies / constraints | Verification |
|---|---|---|---|
| Change website content or page layout | `dist/index.html`, `dist/styles.css` | HTML directly links only these assets plus `app.js`; avoid editing unlinked CSS variants unless intentionally wiring them in | `npm run check`; inspect in a browser/static server |
| Change website behavior/dashboard | `dist/app.js`, relevant `data-*` elements in `dist/index.html` | Demo state is client-side only; Live mode must remain honest unless a real API is added | `npm test` and `npm run check`; browser verification for interactions |
| Add or change a mobile screen | `mobile/src/App.tsx` | Tabs are `TABS` and selected by `Tab` in `mobile/src/types.ts`; app currently owns navigation and shared state | `cd mobile && npm run typecheck`; Android/dev-client validation |
| Change mobile design tokens | `mobile/src/theme.ts`, relevant styles in `mobile/src/App.tsx` | Reuse `colors`/`radius` rather than introducing screen-specific duplicates | Mobile typecheck and visual device check |
| Change demo sample behavior | `mobile/src/services/demoEngine.ts`, `mobile/src/types.ts`, app consumer in `mobile/src/App.tsx` | Preserve `demo: true`; app sample state feeds home/analytics and trip snapshots | Mobile typecheck; test demo mode manually |
| Modify BLE scanning/heart data | `mobile/src/services/ble.ts`, `mobile/src/App.tsx`, `mobile/src/types.ts`, `mobile/app.json` | Android permissions/plugins must stay aligned; real connection needs firmware-approved UUIDs and an actual connection UI flow | Mobile typecheck plus Android development-build/device test |
| Change trip persistence | `mobile/src/services/database.ts`, `mobile/src/App.tsx`, `mobile/src/types.ts` | Schema creation and row mapping must agree; existing database may persist across app upgrades | Mobile typecheck and device test with create/read trip |
| Change location/trip recording | `mobile/src/App.tsx`, `mobile/app.json`, `mobile/src/types.ts` | Current implementation requests foreground permission only; it does not capture or persist GPS coordinates | Verify permission-denied and granted cases on Android; no route behavior exists to regression-test yet |
| Add telemetry/auth/API behavior | `mobile/src/services/telemetry.ts`, `mobile/.env.example`, `server/` | No server endpoint, auth flow, or RLS policies exist. Define and secure the contract before connecting client uploads; never put secrets in `EXPO_PUBLIC_*` | Add server/client tests and verify authorization, validation, and failure handling once a backend exists |
| Change the database draft | `server/supabase/schema.sql`, `server/README.md` | RLS is enabled without policies; schema is not automatically applied | Review SQL and validate against a configured Supabase project; none is configured here |
| Add/edit hardware integration | `hardware/README.md`, `mobile/src/services/ble.ts`, `mobile/src/types.ts` | Select actual hardware and define firmware packet/GATT UUIDs first; never invent UUIDs | Hardware-in-loop Android BLE verification |
| Change build/runtime settings | `mobile/package.json`, `mobile/package-lock.json`, `mobile/app.json`, `mobile/eas.json`, `mobile/tsconfig.json` | Keep lockfile consistent; native plugin/permission changes affect prebuild and Android builds | `npm ci`, mobile typecheck, then relevant Android build |

Common regression risks:

- Accidentally presenting simulated BPM, routes, drivers, or activity as real. Preserve visible demo labels and the empty Live state unless a verified backend is implemented.
- Treating location permission as location tracking. The current app requests permission but does not collect coordinates.
- Treating BLE discovery as successful connection. The app does not currently use the real connection/notification method, and no firmware UUIDs are configured.
- Assuming the telemetry helper is integrated because a URL exists in `.env.example`. It is not called from the app, and no endpoint/auth provider is included.
- Changing SQLite columns without accounting for already-created on-device databases; no migration mechanism is present.
- Editing `dist` assets while assuming a source rebuild will regenerate them. No website source/build pipeline is declared.
- Relying on a mobile typecheck without installing dependencies. The script exists, but it requires the project's `node_modules` (restore with `npm ci` only when allowed/appropriate).

## Current project status and known gaps

### Working behavior

- Static site content, responsive navigation and reveal effects, reduced-motion handling, simulated alert/pairing interactions, dashboard demo values, and an explicit no-live-data state.
- Mobile screen/tab rendering, generated heart samples in demo mode, BLE permission/scan helper, foreground location permission prompt, and local SQLite trip read/write functions.
- Root static checks and a small Node test suite for telemetry-buffer batching behavior.

### Partial or not implemented

- The mobile trip is demo-marked and its distance/speed are simulated. GPS coordinates and real route geometry are not recorded.
- Real bracelet scan exists as helper code, but selection-to-connect/notification flow is not wired in the app; BLE UUIDs and target firmware are absent.
- Analytics periods and alert history are display controls/sample content; the period selection does not change a server query or time window.
- Profile/settings rows are presentation-only. There is no user profile, notification settings, language switching, or account/authentication workflow.
- Telemetry upload helper is not called by the app; there is no backend route or configured Supabase environment.
- Supabase tables have RLS enabled but no access policies. The SQL file is therefore not a production-secure, ready-to-use backend.
- Hardware firmware, production deployment automation, server tests, mobile tests, and a website build pipeline are absent.

### Test coverage

`tests/telemetry.test.js` has two tests for the batching/merge behavior of a local `TelemetryBuffer` class defined in that test file; it does not import or exercise the website's implementation. `tests/check.mjs` is a static assertion script, not an integration/security audit. There are no mobile unit/UI tests or backend tests in the repository. No end-to-end tests verify BLE, location, database persistence, API connectivity, or a production build.

## Critical technical notes

- Handle personal and health-related telemetry as sensitive data. Obtain explicit, informed consent, minimize collection, define retention/deletion, secure transport and storage, and implement role-scoped authorization before production use.
- `mobile/.env.example` contains a placeholder URL only. Any Expo `EXPO_PUBLIC_*` value is client-visible and is not a place for credentials or private keys.
- Do not claim medical diagnosis or emergency-response capability. Current UI messaging states that readings are informational and non-diagnostic.
- `mobile/app.json` configures Bluetooth/location permissions and Expo native plugins. Permission changes require validating the native Android build, not just TypeScript.
- `mobile/src/services/database.ts` serializes sample arrays as JSON and currently reads rows using an untyped SQLite result (`any`). If evolving the model, add deliberate validation/migration rather than assuming persisted rows match the newest TypeScript type.
- Async failures are not consistently surfaced: for example, startup database initialization and trip save/location handling contain swallowed failures. Preserve visibility of errors when improving these paths; avoid treating silent catches as successful operations.
- The root and `dist/` each contain `.openai/hosting.json` with the same `dist` static directory setting. The repository does not explain why both exist; verify the deployment platform's expected config location before changing either.
- The source is highly compressed in some files (notably `mobile/src/App.tsx` and static `dist/app.js`). Keep changes scoped and run the applicable checks after editing.
