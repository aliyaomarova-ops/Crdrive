export type Tab='home'|'bluetooth'|'live'|'history'|'settings';
export type SignalQuality='good'|'weak'|'none';
export type HeartSample={timestamp:number;bpm:number;quality:SignalQuality;demo:boolean};
export type AlertEvent={id:string;timestamp:number;message:string;demo:boolean};
export type Trip={id:string;startedAt:number;endedAt?:number;distanceKm:number;averageSpeed:number;samples:HeartSample[];alerts:number;demo:boolean};
export type BandState={status:'disconnected'|'scanning'|'connecting'|'connected';name?:string;battery?:number;quality:SignalQuality;lastSync?:number;demo:boolean};
export type BleConfig={heartRateServiceUuid?:string;heartRateCharacteristicUuid?:string;batteryServiceUuid?:string;batteryCharacteristicUuid?:string};
