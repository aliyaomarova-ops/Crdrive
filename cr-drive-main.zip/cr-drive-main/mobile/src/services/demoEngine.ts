import type {HeartSample} from '../types';

export class DemoHeartEngine{
  private timer:ReturnType<typeof setInterval>|undefined;
  private bpm=72;
  start(onSample:(sample:HeartSample)=>void){
    this.stop();
    onSample(this.sample());
    this.timer=setInterval(()=>onSample(this.sample()),1500);
  }
  stop(){if(this.timer)clearInterval(this.timer);this.timer=undefined}
  private sample():HeartSample{
    const drift=(Math.random()-.48)*4;
    this.bpm=Math.round(Math.max(62,Math.min(102,this.bpm+drift)));
    return{timestamp:Date.now(),bpm:this.bpm,quality:Math.random()>.08?'good':'weak',demo:true};
  }
}
