import type{HeartSample}from'../types';

export type TelemetryPacket={driverId:string;sessionId:string;sample:HeartSample;latitude:number;longitude:number;accuracy?:number;capturedAt:number};

const endpoint=process.env.EXPO_PUBLIC_TELEMETRY_API_URL?.replace(/\/$/,'');

export function isTelemetryConfigured(){return Boolean(endpoint)}

export async function sendTelemetry(packet:TelemetryPacket,accessToken:string){
  if(!endpoint)throw new Error('Telemetry server is not configured');
  if(!accessToken)throw new Error('Authentication is required');
  const response=await fetch(`${endpoint}/v1/telemetry`,{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${accessToken}`},body:JSON.stringify(packet)});
  if(!response.ok)throw new Error(`Telemetry upload failed: ${response.status}`);
}
