import {BleManager,Device,Subscription} from 'react-native-ble-plx';
import {PermissionsAndroid,Platform} from 'react-native';
import type {BleConfig,HeartSample} from '../types';

export class CRDriveBleClient{
  private manager=new BleManager();
  private monitor?:Subscription;
  private device?:Device;
  async requestPermissions(){
    if(Platform.OS!=='android')return true;
    if(Number(Platform.Version)<31)return (await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION))===PermissionsAndroid.RESULTS.GRANTED;
    const result=await PermissionsAndroid.requestMultiple([PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT]);
    return result[PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN]===PermissionsAndroid.RESULTS.GRANTED&&result[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT]===PermissionsAndroid.RESULTS.GRANTED;
  }
  async scan(onDevice:(device:Device)=>void,onError:(message:string)=>void){
    if(!await this.requestPermissions())throw new Error('Bluetooth permission denied');
    this.manager.startDeviceScan(null,{allowDuplicates:false},(error,device)=>{if(error){onError(error.message);return}if(device?.name)onDevice(device)});
    setTimeout(()=>this.manager.stopDeviceScan(),12000);
  }
  async connect(device:Device,config:BleConfig,onSample:(sample:HeartSample)=>void){
    if(!config.heartRateServiceUuid||!config.heartRateCharacteristicUuid)throw new Error('BLE UUID configuration is required for the production band firmware');
    this.manager.stopDeviceScan();
    this.device=await device.connect({timeout:12000});
    await this.device.discoverAllServicesAndCharacteristics();
    this.monitor=this.device.monitorCharacteristicForService(config.heartRateServiceUuid,config.heartRateCharacteristicUuid,(error,characteristic)=>{
      if(error||!characteristic?.value)return;
      const bytes=Uint8Array.from(atob(characteristic.value),c=>c.charCodeAt(0));
      if(bytes.length<2)return;
      const flags=bytes[0]??0;
      const low=bytes[1]??0;
      const high=bytes[2]??0;
      const bpm=(flags&1)!==0?low|(high<<8):low;
      if(bpm>0)onSample({timestamp:Date.now(),bpm,quality:'good',demo:false});
    });
  }
  async disconnect(){this.monitor?.remove();this.monitor=undefined;if(this.device)await this.manager.cancelDeviceConnection(this.device.id).catch(()=>undefined);this.device=undefined}
  destroy(){this.monitor?.remove();this.manager.destroy()}
}
