import * as SQLite from 'expo-sqlite';
import type {Trip} from '../types';

let dbPromise:ReturnType<typeof SQLite.openDatabaseAsync>|undefined;
const db=()=>dbPromise??=SQLite.openDatabaseAsync('crdrive.db');
export async function initDatabase(){const database=await db();await database.execAsync('PRAGMA journal_mode = WAL; CREATE TABLE IF NOT EXISTS trips (id TEXT PRIMARY KEY NOT NULL, started_at INTEGER NOT NULL, ended_at INTEGER, distance_km REAL NOT NULL DEFAULT 0, average_speed REAL NOT NULL DEFAULT 0, samples_json TEXT NOT NULL, alerts INTEGER NOT NULL DEFAULT 0, demo INTEGER NOT NULL DEFAULT 0);')}
export async function saveTrip(trip:Trip){const database=await db();await database.runAsync('INSERT OR REPLACE INTO trips (id,started_at,ended_at,distance_km,average_speed,samples_json,alerts,demo) VALUES (?,?,?,?,?,?,?,?)',trip.id,trip.startedAt,trip.endedAt??null,trip.distanceKm,trip.averageSpeed,JSON.stringify(trip.samples),trip.alerts,trip.demo?1:0)}
export async function listTrips():Promise<Trip[]>{const database=await db();const rows=await database.getAllAsync<any>('SELECT * FROM trips ORDER BY started_at DESC LIMIT 100');return rows.map(row=>({id:row.id,startedAt:row.started_at,endedAt:row.ended_at??undefined,distanceKm:row.distance_km,averageSpeed:row.average_speed,samples:JSON.parse(row.samples_json),alerts:row.alerts,demo:Boolean(row.demo)}))}
