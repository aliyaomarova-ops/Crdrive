export const colors={bg:'#0B100D',card:'#19221C',cardAlt:'#202B23',lime:'#B5FF59',text:'#FFFFFF',muted:'#9AA9A0',warning:'#FFB84D',danger:'#FF5757',line:'#2B382F'} as const;
export const radius={sm:14,md:20,lg:28,pill:999} as const;
